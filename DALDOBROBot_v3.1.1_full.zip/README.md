# DALDOBROBot v3.1.1 full

Commands:
/start
/lang
/oracle
/mint
/giveaway
/vault
/stream
/launch

Structure:
- Modular
- Multilingual
- NFT-aware